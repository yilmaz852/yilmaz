
<div class="wc-product-table">
    <!-- Table will be displayed by shortcode [wc_product_table category="category_slug"] -->
</div>
