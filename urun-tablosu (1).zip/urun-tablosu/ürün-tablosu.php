<?php
/*
Plugin Name: Ürün Tablosu
Plugin URI: https://example.com
Description: WooCommerce ürünlerini tablo halinde göstermek için kısa kod kullanmanıza olanak tanır.
Version: 1.0
Author: Yılmaz Yıldırım
Author URI: https://example.com
License: GPL2
*/

// Admin menüye ekleme
function urun_tablosu_admin_menu() {
    add_menu_page(
        'Ürün Tablosu Ayarları',
        'Ürün Tablosu',
        'manage_options',
        'urun-tablosu',
        'urun_tablosu_admin_page',
        'dashicons-list-view',
        25
    );
}
add_action('admin_menu', 'urun_tablosu_admin_menu');

// Ayarları kaydetmek için
function urun_tablosu_register_settings() {
    register_setting('urun_tablosu_options_group', 'urun_tablosu_columns');
    register_setting('urun_tablosu_options_group', 'urun_tablosu_widths');
}
add_action('admin_init', 'urun_tablosu_register_settings');

// Admin sayfa içeriği
function urun_tablosu_admin_page() {
    ?>
    <div class="wrap">
        <h1>Ürün Tablosu Ayarları</h1>
        <form method="post" action="options.php">
            <?php settings_fields('urun_tablosu_options_group'); ?>
            <?php do_settings_sections('urun-tablosu'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Görünecek Sütunlar</th>
                    <td>
                        <input type="text" name="urun_tablosu_columns" value="<?php echo esc_attr(get_option('urun_tablosu_columns', 'name,sku,price,add_to_cart')); ?>" style="width: 100%;"/>
                        <p class="description">Örnek: name,sku,price,add_to_cart</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Sütun Genişlikleri</th>
                    <td>
                        <input type="text" name="urun_tablosu_widths" value="<?php echo esc_attr(get_option('urun_tablosu_widths', '25%,25%,25%,25%')); ?>" style="width: 100%;"/>
                        <p class="description">Örnek: 25%,25%,25%,25%</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2>Kısa Kod Kullanımı</h2>
        <p><code>[urun_tablosu kategori="slug" sutunlar="name,sku,price,add_to_cart"]</code></p>
    </div>
    <?php
}

// Kısa kod fonksiyonu
function urun_tablosu_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'kategori' => '', // Kategori slug'ı
            'sutunlar' => 'name,sku,price,add_to_cart', // Sütunlar
        ),
        $atts
    );

    $category_slug = sanitize_title($atts['kategori']); // Güvenlik için temizleme
    $columns = explode(',', $atts['sutunlar']);

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1, // Tüm ürünleri getir
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $category_slug,
            ),
        ),
    );

    $products = new WP_Query($args);

    if ($products->have_posts()) {
        $output = '<table class="urun-tablosu">';
        // Başlık satırı
        $output .= '<thead><tr>';
        foreach ($columns as $column) {
            $output .= '<th>' . ucfirst(trim($column)) . '</th>';
        }
        $output .= '</tr></thead>';

        $output .= '<tbody>';
        while ($products->have_posts()) {
            $products->the_post();
            global $product; // WooCommerce ürün nesnesi

            $output .= '<tr>';
            foreach ($columns as $column) {
                $column = trim($column); // Boşlukları temizle
                $output .= '<td>';

                switch ($column) {
                    case 'name':
                        $output .= get_the_title();
                        break;
                    case 'sku':
                        $output .= $product->get_sku();
                        break;
                    case 'price':
                        $output .= wc_price($product->get_price());
                        break;
                    case 'add_to_cart':
                        $output .= '<a href="' . $product->add_to_cart_url() . '" class="button add_to_cart_button">' . __('Sepete Ekle', 'woocommerce') . '</a>';
                        break;
                    default:
                        $output .= 'Bilinmeyen Sütun';
                        break;
                }

                $output .= '</td>';
            }
            $output .= '</tr>';
        }
        $output .= '</tbody>';

        $output .= '</table>';
        wp_reset_postdata(); // Query'i sıfırla
        return $output;
    } else {
        return '<p>Bu kategoride ürün bulunamadı.</p>';
    }
}
add_shortcode('urun_tablosu', 'urun_tablosu_shortcode');

// Stil ekleme (isteğe bağlı)
function urun_tablosu_enqueue_styles() {
    wp_enqueue_style('urun-tablosu-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'urun_tablosu_enqueue_styles');
?>