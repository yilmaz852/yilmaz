/**
 * Admin JavaScript
 */
jQuery(document).ready(function($) {
    // Tarih alanlarına varsayılan değerler
    if ($('input[name="start_date"]').val() === '') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        $('input[name="start_date"]').val(thirtyDaysAgo.toISOString().split('T')[0]);
    }
    
    if ($('input[name="end_date"]').val() === '') {
        const today = new Date();
        $('input[name="end_date"]').val(today.toISOString().split('T')[0]);
    }
    
    if ($('input[name="chart_start_date"]').val() === '') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        $('input[name="chart_start_date"]').val(thirtyDaysAgo.toISOString().split('T')[0]);
    }
    
    if ($('input[name="chart_end_date"]').val() === '') {
        const today = new Date();
        $('input[name="chart_end_date"]').val(today.toISOString().split('T')[0]);
    }
    
    // CSV dışa aktarma için ek parametreler
    $('#export-csv-form').on('submit', function() {
        // Form elementlerini kopyala
        $('.wc-status-filter-form input, .wc-status-filter-form select').each(function() {
            const name = $(this).attr('name');
            const value = $(this).val();
            
            if (name && value && name !== 'page') {
                $('<input>').attr({
                    type: 'hidden',
                    name: name,
                    value: value
                }).appendTo('#export-csv-form');
            }
        });
    });
});