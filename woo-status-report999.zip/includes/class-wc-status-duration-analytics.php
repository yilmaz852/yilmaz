<?php
/**
 * Gelişmiş analiz ve tahminler için sınıf
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_Analytics {
    /**
     * Trend verisi getir
     */
    public function get_trend_data($table_name, $start_date = null, $end_date = null) {
        global $wpdb;
        
        if (!$start_date) {
            $start_date = date('Y-m-d', strtotime('-30 days'));
        }
        
        if (!$end_date) {
            $end_date = date('Y-m-d');
        }
        
        // Durum bazında günlük ortalama süre verisini al
        $query = $wpdb->prepare(
            "SELECT 
                DATE(a.changed_at) as date,
                a.status,
                AVG(TIMESTAMPDIFF(SECOND, a.changed_at, b.changed_at)) as avg_duration
            FROM 
                {$table_name} a
            JOIN 
                {$table_name} b ON a.order_id = b.order_id AND a.changed_at < b.changed_at
            WHERE 
                a.changed_at BETWEEN %s AND %s
                AND (a.order_id, a.changed_at) IN (
                    SELECT order_id, MAX(changed_at) 
                    FROM {$table_name} x
                    WHERE x.changed_at < b.changed_at
                    GROUP BY order_id
                )
            GROUP BY 
                DATE(a.changed_at), a.status
            ORDER BY 
                date ASC",
            $start_date . ' 00:00:00',
            $end_date . ' 23:59:59'
        );
        
        $results = $wpdb->get_results($query);
        
        // Sonuçları düzenle
        $trend_data = [];
        $dates = [];
        $statuses = [];
        
        foreach ($results as $row) {
            if (!isset($trend_data[$row->status])) {
                $trend_data[$row->status] = [];
                $statuses[] = $row->status;
            }
            
            $trend_data[$row->status][$row->date] = round($row->avg_duration);
            
            if (!in_array($row->date, $dates)) {
                $dates[] = $row->date;
            }
        }
        
        // Eksik tarihleri doldur
        foreach ($statuses as $status) {
            foreach ($dates as $date) {
                if (!isset($trend_data[$status][$date])) {
                    $trend_data[$status][$date] = 0;
                }
            }
            // Tarihleri sırala
            ksort($trend_data[$status]);
        }
        
        return [
            'data' => $trend_data,
            'dates' => $dates,
            'statuses' => $statuses
        ];
    }
    
    /**
     * Tahmin doğruluğunu hesapla
     */
    public function get_prediction_accuracy() {
        // Bu sadece örnek veri döndürür
        // Gerçek uygulamada, tahmin doğruluğunu hesaplamak için
        // önceki tahminleri ve gerçek sonuçları karşılaştırmalısınız
        return [
            'accuracy_percentage' => 85,
            'avg_error' => 1200,
        ];
    }
    
    /**
     * Gelişmiş grafikleri render et
     */
    public function render_advanced_charts($table_name) {
        // Tarih filtresi için
        $start_date = isset($_GET['chart_start_date']) ? sanitize_text_field($_GET['chart_start_date']) : date('Y-m-d', strtotime('-30 days'));
        $end_date = isset($_GET['chart_end_date']) ? sanitize_text_field($_GET['chart_end_date']) : date('Y-m-d');
        
        // Filtreleme formu ekle
        echo '<form method="get" action="">';
        echo '<input type="hidden" name="page" value="wc-status-duration-analysis">';
        echo '<div class="date-filter">';
        echo '<label for="chart_start_date">Başlangıç Tarihi:</label>';
        echo '<input type="date" id="chart_start_date" name="chart_start_date" value="' . esc_attr($start_date) . '">';
        
        echo '<label for="chart_end_date">Bitiş Tarihi:</label>';
        echo '<input type="date" id="chart_end_date" name="chart_end_date" value="' . esc_attr($end_date) . '">';
        
        echo '<input type="submit" class="button" value="Filtrele">';
        echo '</div>';
        echo '</form>';
        
        // Trend verisini al
        $trend_data = $this->get_trend_data($table_name, $start_date, $end_date);
        
        // Veri varsa göster
        if (!empty($trend_data['data'])) {
            echo '<div class="analytics-container">';
            echo '<h2>Durum Bazında Günlük Ortalama Süre Trendi</h2>';
            echo '<div style="width:100%; height:400px;">';
            echo '<canvas id="trendChart"></canvas>';
            echo '</div>';
            
            // Grafik için JavaScript kodu
            ?>
            <script>
            jQuery(document).ready(function($) {
                var ctx = document.getElementById('trendChart').getContext('2d');
                
                // Veri hazırlama
                var datasets = [];
                var colors = [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
                    '#6f42c1', '#fd7e14', '#20c997', '#f8f9fc', '#858796'
                ];
                
                <?php
                $color_index = 0;
                foreach ($trend_data['data'] as $status => $dates):
                ?>
                datasets.push({
                    label: '<?php echo esc_js($status); ?>',
                    data: <?php echo json_encode(array_values($dates)); ?>,
                    fill: false,
                    borderColor: colors[<?php echo $color_index % count($colors); ?>],
                    backgroundColor: colors[<?php echo $color_index % count($colors); ?>],
                    tension: 0.1
                });
                <?php
                $color_index++;
                endforeach;
                ?>
                
                var trendChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($trend_data['dates']); ?>,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Ortalama Süre (saniye)'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Tarih'
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        var seconds = context.raw;
                                        var hours = Math.floor(seconds / 3600);
                                        var minutes = Math.floor((seconds % 3600) / 60);
                                        var secs = seconds % 60;
                                        
                                        return context.dataset.label + ': ' + 
                                            (hours < 10 ? '0' + hours : hours) + ':' + 
                                            (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                                            (secs < 10 ? '0' + secs : secs);
                                    }
                                }
                            },
                            legend: {
                                position: 'top',
                            }
                        }
                    }
                });
            });
            </script>
            <?php
            
            echo '</div>';
            
            // Durum geçiş dağılımı grafiği ekle
            echo '<div class="analytics-container">';
            echo '<h2>Durum Geçiş Dağılımı</h2>';
            echo '<div style="width:100%; height:400px;">';
            echo '<canvas id="distributionChart"></canvas>';
            echo '</div>';
            
            // Durum dağılımı verisi için sorgu
            global $wpdb;
            
            $distribution_data = $wpdb->get_results($wpdb->prepare(
                "SELECT 
                    status, 
                    COUNT(*) as count 
                FROM 
                    {$table_name} 
                WHERE 
                    changed_at BETWEEN %s AND %s 
                GROUP BY 
                    status",
                $start_date . ' 00:00:00',
                $end_date . ' 23:59:59'
            ));
            
            $labels = [];
            $data = [];
            
            foreach ($distribution_data as $row) {
                $labels[] = $row->status;
                $data[] = $row->count;
            }
            
            ?>
            <script>
            jQuery(document).ready(function($) {
                var ctx = document.getElementById('distributionChart').getContext('2d');
                
                var backgroundColors = [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
                    '#6f42c1', '#fd7e14', '#20c997', '#f8f9fc', '#858796'
                ];
                
                var distributionChart = new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: <?php echo json_encode($labels); ?>,
                        datasets: [{
                            data: <?php echo json_encode($data); ?>,
                            backgroundColor: backgroundColors.slice(0, <?php echo count($labels); ?>)
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',
                            },
                            title: {
                                display: true,
                                text: 'Durum Dağılımı'
                            }
                        }
                    }
                });
            });
            </script>
            <?php
            
            echo '</div>';
            
            // Haftanın günlerine göre analiz
            echo '<div class="analytics-container">';
            echo '<h2>Haftanın Günlerine Göre Durum Süreleri</h2>';
            echo '<div style="width:100%; height:400px;">';
            echo '<canvas id="weekdayChart"></canvas>';
            echo '</div>';
            
            // Haftanın günlerine göre veriler
            $weekday_data = $wpdb->get_results($wpdb->prepare(
                "SELECT 
                    DAYOFWEEK(a.changed_at) as weekday,
                    a.status,
                    AVG(TIMESTAMPDIFF(SECOND, a.changed_at, b.changed_at)) as avg_duration
                FROM 
                    {$table_name} a
                JOIN 
                    {$table_name} b ON a.order_id = b.order_id AND a.changed_at < b.changed_at
                WHERE 
                    a.changed_at BETWEEN %s AND %s
                    AND (a.order_id, a.changed_at) IN (
                        SELECT order_id, MAX(changed_at) 
                        FROM {$table_name} x
                        WHERE x.changed_at < b.changed_at
                        GROUP BY order_id
                    )
                GROUP BY 
                    DAYOFWEEK(a.changed_at), a.status
                ORDER BY 
                    weekday ASC",
                $start_date . ' 00:00:00',
                $end_date . ' 23:59:59'
            ));
            
            // Verileri düzenle
            $weekday_trend = [];
            $weekday_labels = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
            
            foreach ($weekday_data as $row) {
                // MySQL DAYOFWEEK 1=Pazar, 2=Pazartesi, ...
                $weekday_index = $row->weekday - 1; // 0-indeksli dizi için -1
                
                if (!isset($weekday_trend[$row->status])) {
                    $weekday_trend[$row->status] = array_fill(0, 7, 0);
                }
                
                $weekday_trend[$row->status][$weekday_index] = round($row->avg_duration);
            }
            
            ?>
            <script>
            jQuery(document).ready(function($) {
                var ctx = document.getElementById('weekdayChart').getContext('2d');
                
                var datasets = [];
                var colors = [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
                    '#6f42c1', '#fd7e14', '#20c997', '#f8f9fc', '#858796'
                ];
                
                <?php
                $color_index = 0;
                foreach ($weekday_trend as $status => $data):
                ?>
                datasets.push({
                    label: '<?php echo esc_js($status); ?>',
                    data: <?php echo json_encode(array_values($data)); ?>,
                    backgroundColor: colors[<?php echo $color_index % count($colors); ?>]
                });
                <?php
                $color_index++;
                endforeach;
                ?>
                
                var weekdayChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($weekday_labels); ?>,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Ortalama Süre (saniye)'
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        var seconds = context.raw;
                                        var hours = Math.floor(seconds / 3600);
                                        var minutes = Math.floor((seconds % 3600) / 60);
                                        var secs = seconds % 60;
                                        
                                        return context.dataset.label + ': ' + 
                                            (hours < 10 ? '0' + hours : hours) + ':' + 
                                            (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                                            (secs < 10 ? '0' + secs : secs);
                                    }
                                }
                            }
                        }
                    }
                });
            });
            </script>
            <?php
            
            echo '</div>';
            
        } else {
            echo '<div class="notice notice-warning"><p>Seçilen tarih aralığında veri bulunamadı.</p></div>';
        }
    }
}