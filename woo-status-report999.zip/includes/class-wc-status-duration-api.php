<?php
/**
 * Takvim ve sipariş detayları için API işlemleri
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_API {
    private $table_name;
    private $cache;
    
    public function __construct($table_name, $cache) {
        $this->table_name = $table_name;
        $this->cache = $cache;
        
        add_action('wp_ajax_wc_status_get_calendar_events', [$this, 'ajax_get_calendar_events']);
        add_action('wp_ajax_wc_status_get_order_details', [$this, 'ajax_get_order_details']);
        add_action('wp_ajax_wc_status_update_order_schedule', [$this, 'ajax_update_order_schedule']);
        add_action('wp_ajax_wc_status_duration_clear_cache', [$this, 'ajax_clear_cache']);
    }
    
    /**
     * Takvim olaylarını getir
     */
    public function ajax_get_calendar_events() {
        check_ajax_referer('wc_status_get_calendar_events', 'security');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'İzin hatası']);
            return;
        }
        
        // İsteğin parametrelerini al
        $start = isset($_POST['start']) ? sanitize_text_field($_POST['start']) : date('Y-m-d', strtotime('-1 month'));
        $end = isset($_POST['end']) ? sanitize_text_field($_POST['end']) : date('Y-m-d', strtotime('+3 months'));
        $status_filter = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        
        // Planlanmış siparişleri getir
        $events = [];
        
        // Üretim programından siparişleri al
        $args = [
            'post_type'      => 'shop_order',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_query'     => [
                [
                    'key'     => '_production_schedule_date',
                    'value'   => [$start, $end],
                    'compare' => 'BETWEEN',
                    'type'    => 'DATE'
                ]
            ]
        ];
        
        // Durum filtresi ekle
        if (!empty($status_filter)) {
            $args['meta_query'][] = [
                'key'     => '_status',
                'value'   => $status_filter,
                'compare' => '='
            ];
        }
        
        $query = new WP_Query($args);
        
        if ($query->have_posts()) {
            $colors = [
                'processing' => '#1e73be',
                'on-hold'    => '#f8c100',
                'pending'    => '#ffba00',
                'completed'  => '#2ea2cc',
                'cancelled'  => '#a00',
                'refunded'   => '#999',
                'failed'     => '#d0021b',
            ];
            
            while ($query->have_posts()) {
                $query->the_post();
                $order_id = get_the_ID();
                $order = wc_get_order($order_id);
                
                if (!$order) continue;
                
                $order_status = $order->get_status();
                $color = isset($colors[$order_status]) ? $colors[$order_status] : '#999999';
                
                $schedule_date = get_post_meta($order_id, '_production_schedule_date', true);
                $start_time = get_post_meta($order_id, '_production_schedule_start', true);
                $end_time = get_post_meta($order_id, '_production_schedule_end', true);
                
                $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                
                $events[] = [
                    'id'    => $order_id,
                    'title' => '#' . $order_id . ' - ' . $customer_name,
                    'start' => $schedule_date . 'T' . $start_time,
                    'end'   => $schedule_date . 'T' . $end_time,
                    'color' => $color,
                    'textColor' => '#fff',
                    'url'   => '#', // Takvimde URL'ye yönlendirmeyi devreden çıkarır
                    'extendedProps' => [
                        'status' => $order_status,
                        'total'  => $order->get_formatted_order_total()
                    ]
                ];
            }
            
            wp_reset_postdata();
        }
        
        wp_send_json($events);
    }
    
    /**
     * Sipariş detaylarını getir
     */
    public function ajax_get_order_details() {
        check_ajax_referer('wc_status_get_order_details', 'security');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'İzin hatası']);
            return;
        }
        
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        
        if (!$order_id) {
            wp_send_json_error(['message' => 'Geçersiz sipariş ID']);
            return;
        }
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error(['message' => 'Sipariş bulunamadı']);
            return;
        }
        
        // Sipariş detay HTML'ini oluştur
        $html = '<div class="order-details">';
        
        $html .= '<table class="widefat" style="margin-bottom:15px;">';
        $html .= '<tr><th>Sipariş No</th><td>#' . $order->get_order_number() . '</td></tr>';
        $html .= '<tr><th>Tarih</th><td>' . $order->get_date_created()->date_i18n('d F Y H:i') . '</td></tr>';
        $html .= '<tr><th>Durum</th><td>' . wc_get_order_status_name($order->get_status()) . '</td></tr>';
        $html .= '<tr><th>Müşteri</th><td>' . $order->get_formatted_billing_full_name() . '</td></tr>';
        $html .= '<tr><th>Toplam</th><td>' . $order->get_formatted_order_total() . '</td></tr>';
        
        // Üretim bilgilerini ekle
        $schedule_date = get_post_meta($order_id, '_production_schedule_date', true);
        $start_time = get_post_meta($order_id, '_production_schedule_start', true);
        $end_time = get_post_meta($order_id, '_production_schedule_end', true);
        
        if ($schedule_date) {
            $formatted_date = date_i18n('d F Y', strtotime($schedule_date));
            $html .= '<tr><th>Üretim Tarihi</th><td>' . $formatted_date . '</td></tr>';
            $html .= '<tr><th>Planlanan Zaman</th><td>' . $start_time . ' - ' . $end_time . '</td></tr>';
        }
        
        $html .= '</table>';
        
        // Ürün listesi
        $html .= '<h3>Ürünler</h3>';
        $html .= '<table class="widefat">';
        $html .= '<tr><th>Ürün</th><th>Miktar</th><th>Toplam</th></tr>';
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $product_name = $product ? $product->get_name() : $item->get_name();
            
            $html .= '<tr>';
            $html .= '<td>' . $product_name . '</td>';
            $html .= '<td>' . $item->get_quantity() . '</td>';
            $html .= '<td>' . $order->get_formatted_line_subtotal($item) . '</td>';
            $html .= '</tr>';
        }
        
        $html .= '</table>';
        
        // Sipariş notları
        $customer_note = $order->get_customer_note();
        if (!empty($customer_note)) {
            $html .= '<h3>Müşteri Notu</h3>';
            $html .= '<p>' . nl2br(esc_html($customer_note)) . '</p>';
        }
        
        $html .= '</div>';
        
        wp_send_json_success(['html' => $html]);
    }
    
    /**
     * Sipariş programını güncelle
     */
    public function ajax_update_order_schedule() {
        check_ajax_referer('wc_status_update_order_schedule', 'security');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'İzin hatası']);
            return;
        }
        
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $new_date = isset($_POST['new_date']) ? sanitize_text_field($_POST['new_date']) : '';
        
        if (!$order_id || !$new_date || !strtotime($new_date)) {
            wp_send_json_error(['message' => 'Geçersiz parametreler']);
            return;
        }
        
        // Günün çalışma günü olup olmadığını kontrol et
        $date = new DateTime($new_date);
        $day_name = strtolower($date->format('l'));
        
        $working_days = get_option('wc_status_duration_working_days', ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']);
        
        if (!in_array($day_name, $working_days)) {
            wp_send_json_error(['message' => 'Seçilen gün çalışma günü değil.']);
            return;
        }
        
        // Mevcut planlamayı güncelle
        update_post_meta($order_id, '_production_schedule_date', $new_date);
        
        // Önbelleği temizle
        $this->cache->clear_cache();
        
        wp_send_json_success();
    }
    
    /**
     * Önbelleği temizle
     */
    public function ajax_clear_cache() {
        check_ajax_referer('wc_status_duration_clear_cache', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('İzin hatası');
            return;
        }
        
        $this->cache->clear_cache();
        
        wp_send_json_success([
            'message' => 'Önbellek başarıyla temizlendi.'
        ]);
    }
}