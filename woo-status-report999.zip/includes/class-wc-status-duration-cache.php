<?php
/**
 * Önbellek yönetimi için sınıf
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_Cache {
    private $cache_group = 'wc_status_duration';
    private $cache_time;
    
    public function __construct() {
        $this->cache_time = get_option('wc_status_duration_cache_time', 3600); // Varsayılan 1 saat
    }
    
    /**
     * Önbellekten veri getir veya oluştur
     */
    public function get_cached_data($key, $callback, $callback_args = []) {
        $cache_key = $this->cache_group . '_' . md5(serialize($key));
        $cached_data = wp_cache_get($cache_key, $this->cache_group);
        
        if (false !== $cached_data) {
            return $cached_data;
        }
        
        // Cache yoksa veriyi oluştur
        $data = call_user_func_array($callback, $callback_args);
        
        wp_cache_set($cache_key, $data, $this->cache_group, $this->cache_time);
        
        return $data;
    }
    
    /**
     * Önbelleği temizle
     */
    public function clear_cache() {
        wp_cache_flush();
    }
    
    /**
     * Database optimizasyonu
     */
    public function optimize_queries($table_name, $per_page = 1000) {
        global $wpdb;
        
        // Örnek: Eski kayıtları arşivleme
        $date_threshold = date('Y-m-d', strtotime('-6 months'));
        
        // Bu sadece bir örnek - gerçek uygulamada, arşiv tablosu oluşturma ve taşıma işlemleri daha kompleks olabilir
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_name} WHERE changed_at < %s",
            $date_threshold . ' 00:00:00'
        ));
        
        // İndeks kontrolü
        $wpdb->query("ANALYZE TABLE {$table_name}");
    }
}