<?php
/**
 * Dashboard widget ve bildirimler için sınıf
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_Dashboard {
    private $table_name;
    
    public function __construct($table_name) {
        $this->table_name = $table_name;
        add_action('wp_dashboard_setup', [$this, 'add_dashboard_widget']);
        add_action('woocommerce_order_status_changed', [$this, 'check_duration_thresholds'], 20, 4);
    }
    
    /**
     * Dashboard widget'ı ekle
     */
    public function add_dashboard_widget() {
        if (current_user_can('manage_woocommerce')) {
            wp_add_dashboard_widget(
                'wc_status_duration_summary',
                'Sipariş Durumu Özeti',
                [$this, 'render_dashboard_widget']
            );
        }
    }
    
    /**
     * Dashboard widget içeriğini oluştur
     */
    public function render_dashboard_widget() {
        global $wpdb;
        
        // Son 7 gündeki durumlar
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT 
                    a.status, 
                    COUNT(*) as count, 
                    AVG(TIMESTAMPDIFF(SECOND, a.changed_at, b.changed_at)) as avg_duration
                FROM 
                    {$this->table_name} a
                JOIN 
                    {$this->table_name} b ON a.order_id = b.order_id AND a.id < b.id
                WHERE 
                    a.changed_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY 
                    a.status
                ORDER BY 
                    count DESC
                LIMIT 5",
                []
            )
        );
        
        echo '<div class="summary-statistics">';
        echo '<h4>Son 7 Gün - Durum Süreleri</h4>';
        echo '<table class="widefat"><tr><th>Durum</th><th>Sipariş Sayısı</th><th>Ortalama Süre</th></tr>';
        
        if (empty($results)) {
            echo '<tr><td colspan="3">Veri yok</td></tr>';
        } else {
            foreach ($results as $row) {
                echo '<tr>';
                echo '<td>' . esc_html($row->status) . '</td>';
                echo '<td>' . esc_html($row->count) . '</td>';
                echo '<td>' . gmdate('H:i:s', round($row->avg_duration)) . '</td>';
                echo '</tr>';
            }
        }
        
        echo '</table>';
        echo '<p><a href="' . admin_url('admin.php?page=wc-status-duration-report') . '">Detaylı rapora git &raquo;</a></p>';
        
        // Açık durumda olan siparişler
        $open_orders_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT order_id) FROM {$this->table_name} 
                WHERE status NOT IN ('completed', 'cancelled', 'refunded')
                AND order_id NOT IN (
                    SELECT order_id FROM {$this->table_name} 
                    WHERE status IN ('completed', 'cancelled', 'refunded')
                )",
                []
            )
        );
        
        echo '<div class="stat-summary">';
        echo '<p>Açık Sipariş Sayısı: <strong>' . (int)$open_orders_count . '</strong></p>';
        echo '</div>';
        
        echo '</div>';
    }
    
    /**
     * Sipariş durum değişikliğinde süre eşiklerini kontrol et
     */
    public function check_duration_thresholds($order_id, $old_status, $new_status, $order) {
        if (!get_option('wc_status_duration_notifications_enabled', 0)) {
            return;
        }
        
        global $wpdb;
        
        // Eski durumda ne kadar kaldığını hesapla
        $prev_timestamp = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(changed_at) FROM {$this->table_name} WHERE order_id = %d AND status = %s",
            $order_id, $old_status
        ));
        
        if ($prev_timestamp) {
            $duration = time() - strtotime($prev_timestamp);
            
            // Eşik değerini aş (saat -> saniye dönüşümü)
            $threshold = get_option('wc_status_duration_threshold', 24) * 3600;
            if ($duration > $threshold) {
                $this->send_threshold_notification($order_id, $old_status, $new_status, $duration);
            }
        }
    }
    
    /**
     * Eşik aşıldığında bildirim gönder
     */
    private function send_threshold_notification($order_id, $old_status, $new_status, $duration) {
        $emails = get_option('wc_status_duration_emails', get_option('admin_email'));
        $email_list = explode(',', $emails);
        
        $subject = sprintf('Sipariş #%s uzun süre "%s" durumunda kaldı', $order_id, $old_status);
        $message = sprintf(
            'Sipariş #%s, "%s" durumunda %s süre kaldıktan sonra "%s" durumuna geçti.',
            $order_id,
            $old_status,
            human_time_diff(time() - $duration, time()),
            $new_status
        );
        
        $message .= "\n\n";
        $message .= admin_url('post.php?post=' . $order_id . '&action=edit');
        
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        
        foreach ($email_list as $email) {
            wp_mail(trim($email), $subject, nl2br($message), $headers);
        }
    }
}