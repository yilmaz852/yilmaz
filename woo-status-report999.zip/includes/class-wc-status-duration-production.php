            return;
        }
        
        // Siparişleri planla
        $work_start_time = get_option('wc_status_duration_work_hours_start', '09:00');
        $current_time = $work_start_time;
        
        foreach ($order_ids as $order_id) {
            if (!isset($open_orders[$order_id])) continue;
            
            $duration = $open_orders[$order_id]['estimated_duration'];
            $start_time = $current_time;
            $end_time = $this->add_minutes_to_time($start_time, $duration);
            
            // Meta verisini güncelle
            update_post_meta($order_id, '_production_schedule_date', $schedule_date);
            update_post_meta($order_id, '_production_schedule_start', $start_time);
            update_post_meta($order_id, '_production_schedule_end', $end_time);
            
            // Sonraki sipariş için başlangıç zamanını güncelle
            $current_time = $end_time;
        }
        
        wp_send_json_success();
    }
    
    /**
     * Açık siparişleri getir
     */
    private function get_open_orders() {
        global $wpdb;
        
        // Önbellekten veri al
        return $this->cache->get_cached_data('open_orders', function() use ($wpdb) {
            // Açık durumda olan siparişleri al (tamamlanmamış, iptal edilmemiş, iade edilmemiş)
            $results = $wpdb->get_results(
                "SELECT 
                    posts.ID as order_id, 
                    MAX(posts.post_date) as order_date,
                    pm.meta_value as status
                FROM 
                    {$wpdb->posts} posts
                LEFT JOIN 
                    {$wpdb->postmeta} pm ON posts.ID = pm.post_id AND pm.meta_key = '_status'
                WHERE 
                    posts.post_type = 'shop_order' 
                    AND pm.meta_value NOT IN ('completed', 'cancelled', 'refunded')
                GROUP BY 
                    posts.ID
                ORDER BY 
                    posts.post_date DESC"
            );
            
            $orders = [];
            
            foreach ($results as $row) {
                $order_id = $row->order_id;
                $status = $row->status;
                
                if (empty($status)) continue;
                
                // Sipariş için tahmini süreyi hesapla
                $orders[$order_id] = [
                    'status' => $status,
                    'order_date' => $row->order_date,
                    'estimated_duration' => $this->calculate_estimated_duration($order_id, $status)
                ];
            }
            
            return $orders;
        });
    }
    
    /**
     * Belirli bir gün için planlanmış siparişleri getir
     */
    private function get_scheduled_orders($date) {
        // Önbellekten veri al
        $cache_key = 'scheduled_orders_' . $date;
        
        return $this->cache->get_cached_data($cache_key, function() use ($date) {
            // _production_schedule_date meta key ile sorgu yap
            $args = [
                'post_type'      => 'shop_order',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'meta_query'     => [
                    [
                        'key'     => '_production_schedule_date',
                        'value'   => $date,
                        'compare' => '='
                    ]
                ]
            ];
            
            $query = new WP_Query($args);
            $orders = [];
            
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $order_id = get_the_ID();
                    
                    // Sipariş için planlama verilerini al
                    $start_time = get_post_meta($order_id, '_production_schedule_start', true);
                    $end_time = get_post_meta($order_id, '_production_schedule_end', true);
                    
                    // Başlangıç ve bitiş zamanı arasındaki dakika farkını hesapla
                    $start_datetime = DateTime::createFromFormat('H:i', $start_time);
                    $end_datetime = DateTime::createFromFormat('H:i', $end_time);
                    
                    $duration = 0;
                    if ($start_datetime && $end_datetime) {
                        $interval = $start_datetime->diff($end_datetime);
                        $duration = ($interval->h * 60) + $interval->i;
                    }
                    
                    $orders[$order_id] = [
                        'start_time' => $start_time,
                        'end_time'   => $end_time,
                        'duration'   => $duration
                    ];
                }
                
                wp_reset_postdata();
            }
            
            // Başlangıç zamanına göre sırala
            uasort($orders, function($a, $b) {
                return strcmp($a['start_time'], $b['start_time']);
            });
            
            return $orders;
        });
    }
    
    /**
     * Günlük üretim kapasitesini hesapla
     */
    private function calculate_daily_capacity($date) {
        $staff_count = get_option('wc_status_duration_staff_count', 1);
        $work_start = get_option('wc_status_duration_work_hours_start', '09:00');
        $work_end = get_option('wc_status_duration_work_hours_end', '17:00');
        
        // Başlangıç ve bitiş zamanı arasındaki dakika farkını hesapla
        $start_datetime = DateTime::createFromFormat('H:i', $work_start);
        $end_datetime = DateTime::createFromFormat('H:i', $work_end);
        
        $minutes_per_day = 480; // Varsayılan (8 saat)
        
        if ($start_datetime && $end_datetime) {
            $interval = $start_datetime->diff($end_datetime);
            $minutes_per_day = ($interval->h * 60) + $interval->i;
        }
        
        // Toplam kapasiteyi hesapla (personel sayısı * günlük dakika)
        $total_capacity = $staff_count * $minutes_per_day;
        
        return [
            'staff_count' => $staff_count,
            'work_hours' => $work_start . ' - ' . $work_end,
            'minutes_per_day' => $minutes_per_day,
            'total_minutes' => $total_capacity
        ];
    }
    
    /**
     * Sipariş ve durumuna göre tahmini süreyi hesapla
     */
    private function calculate_estimated_duration($order_id, $status) {
        // Durum için ayarlanmış varsayılan süreyi kontrol et
        $default_duration = get_option('wc_status_duration_estimate_' . $status, 60); // Varsayılan 60 dakika
        
        // Sipariş özel meta verisi kontrolü
        $custom_duration = get_post_meta($order_id, '_estimated_production_time', true);
        if ($custom_duration) {
            return (int)$custom_duration;
        }
        
        // Sipariş içeriğine göre süreyi hesaplama
        $order = wc_get_order($order_id);
        if ($order) {
            // Ürün sayısına göre ekstra süre ekle
            $item_count = count($order->get_items());
            $additional_time = ($item_count > 1) ? (($item_count - 1) * 15) : 0; // Her ekstra ürün için 15 dakika
            return $default_duration + $additional_time;
        }
        
        return (int)$default_duration;
    }
    
    /**
     * Dakikaları saat:dakika formatına dönüştür
     */
    private function format_minutes($minutes) {
        $hours = floor($minutes / 60);
        $mins = $minutes % 60;
        return sprintf('%d saat %d dakika', $hours, $mins);
    }
    
    /**
     * Bir saate belirli sayıda dakika ekle
     */
    private function add_minutes_to_time($time, $minutes) {
        $datetime = DateTime::createFromFormat('H:i', $time);
        if (!$datetime) {
            return $time;
        }
        
        $datetime->modify('+' . $minutes . ' minutes');
        return $datetime->format('H:i');
    }
}