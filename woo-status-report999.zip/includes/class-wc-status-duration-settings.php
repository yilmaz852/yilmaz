<?php
/**
 * WooCommerce Sipariş Durum Süre Raporu için ayarlar sınıfı
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_Settings {
    private $table_name;
    
    public function __construct($table_name) {
        $this->table_name = $table_name;
        add_action('admin_init', [$this, 'register_settings']);
    }
    
    /**
     * Ayarları kaydet
     */
    public function register_settings() {
        // Bildirim ayarları
        register_setting('wc_status_duration_settings_group', 'wc_status_duration_notifications_enabled', 'intval');
        register_setting('wc_status_duration_settings_group', 'wc_status_duration_threshold', 'intval');
        register_setting('wc_status_duration_settings_group', 'wc_status_duration_emails', 'sanitize_text_field');
        register_setting('wc_status_duration_settings_group', 'wc_status_duration_cache_time', 'intval');
        
        // Personel ve Çalışma Saatleri Ayarları
        register_setting('wc_status_duration_production_group', 'wc_status_duration_staff_count', 'intval');
        register_setting('wc_status_duration_production_group', 'wc_status_duration_work_hours_start', [$this, 'sanitize_time']);
        register_setting('wc_status_duration_production_group', 'wc_status_duration_work_hours_end', [$this, 'sanitize_time']);
        register_setting('wc_status_duration_production_group', 'wc_status_duration_working_days', [$this, 'sanitize_working_days']);
        
        // Status bazında süre tahminleri
        $statuses = $this->get_all_statuses();
        foreach ($statuses as $status => $label) {
            register_setting(
                'wc_status_duration_estimates_group', 
                'wc_status_duration_estimate_' . $status, 
                'intval'
            );
        }
        
        // Ayarlar bölümleri
        add_settings_section(
            'wc_status_duration_notification_section',
            'Bildirim Ayarları',
            function() { echo '<p>Bu ayarlar, sipariş durumu süresi için bildirimleri yapılandırmak içindir.</p>'; },
            'wc_status_duration_settings'
        );
        
        add_settings_section(
            'wc_status_duration_production_section',
            'Üretim Ayarları',
            function() { echo '<p>Bu ayarlar, üretim kapasitesini ve çalışma saatlerini belirlemek içindir.</p>'; },
            'wc_status_duration_production'
        );
        
        add_settings_section(
            'wc_status_duration_estimates_section',
            'Durum Süresi Tahminleri',
            function() { echo '<p>Her durum için beklenen süreleri (dakika olarak) ayarlayın.</p>'; },
            'wc_status_duration_estimates'
        );
        
        // Bildirim ayarları alanları
        add_settings_field(
            'wc_status_duration_notifications_enabled',
            'Bildirimler Aktif',
            [$this, 'notifications_enabled_callback'],
            'wc_status_duration_settings',
            'wc_status_duration_notification_section'
        );
        
        add_settings_field(
            'wc_status_duration_threshold',
            'Maksimum Durum Süresi (saat)',
            [$this, 'threshold_callback'],
            'wc_status_duration_settings',
            'wc_status_duration_notification_section'
        );
        
        add_settings_field(
            'wc_status_duration_emails',
            'Bildirim E-postaları',
            [$this, 'emails_callback'],
            'wc_status_duration_settings',
            'wc_status_duration_notification_section'
        );
        
        // Üretim ayarları alanları
        add_settings_field(
            'wc_status_duration_staff_count',
            'Personel Sayısı',
            [$this, 'staff_count_callback'],
            'wc_status_duration_production',
            'wc_status_duration_production_section'
        );
        
        add_settings_field(
            'wc_status_duration_work_hours',
            'Çalışma Saatleri',
            [$this, 'work_hours_callback'],
            'wc_status_duration_production',
            'wc_status_duration_production_section'
        );
        
        add_settings_field(
            'wc_status_duration_working_days',
            'Çalışma Günleri',
            [$this, 'working_days_callback'],
            'wc_status_duration_production',
            'wc_status_duration_production_section'
        );
        
        // Her durum için tahmin alanları
        foreach ($statuses as $status => $label) {
            add_settings_field(
                'wc_status_duration_estimate_' . $status,
                $label,
                [$this, 'estimate_field_callback'],
                'wc_status_duration_estimates',
                'wc_status_duration_estimates_section',
                ['status' => $status]
            );
        }
    }
    
    /**
     * Tüm sipariş durumlarını getir
     */
    public function get_all_statuses() {
        global $wpdb;
        $results = $wpdb->get_results("SELECT DISTINCT status FROM {$this->table_name}");
        
        $statuses = [];
        // Standart WooCommerce durumları
        $wc_statuses = wc_get_order_statuses();
        
        // Veritabanından alınan durumları ekle
        foreach ($results as $row) {
            $status_key = 'wc-' . $row->status;
            if (isset($wc_statuses[$status_key])) {
                $statuses[$row->status] = $wc_statuses[$status_key];
            } else {
                $statuses[$row->status] = ucfirst($row->status);
            }
        }
        
        return $statuses;
    }
    
    /**
     * Saat formatını doğrulama
     */
    public function sanitize_time($time) {
        if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
            return '09:00';
        }
        return $time;
    }
    
    /**
     * Çalışma günleri dizisini doğrulama
     */
    public function sanitize_working_days($days) {
        if (!is_array($days)) {
            return ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
        }
        
        $valid_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        return array_intersect($days, $valid_days);
    }
    
    // Bildirim ayarları için callback fonksiyonları
    public function notifications_enabled_callback() {
        $enabled = get_option('wc_status_duration_notifications_enabled', 0);
        echo '<input type="checkbox" name="wc_status_duration_notifications_enabled" value="1" ' . checked(1, $enabled, false) . '>';
    }
    
    public function threshold_callback() {
        $threshold = get_option('wc_status_duration_threshold', 24);
        echo '<input type="number" name="wc_status_duration_threshold" value="' . esc_attr($threshold) . '">';
    }
    
    public function emails_callback() {
        $emails = get_option('wc_status_duration_emails', get_option('admin_email'));
        echo '<input type="text" name="wc_status_duration_emails" value="' . esc_attr($emails) . '" style="width:300px">';
        echo '<p class="description">Birden fazla e-posta için virgül kullanın</p>';
    }
    
    // Üretim ayarları için callback fonksiyonları
    public function staff_count_callback() {
        $staff_count = get_option('wc_status_duration_staff_count', 1);
        echo '<input type="number" name="wc_status_duration_staff_count" value="' . esc_attr($staff_count) . '" min="1">';
        echo '<p class="description">Üretimde çalışan personel sayısı</p>';
    }
    
    public function work_hours_callback() {
        $start = get_option('wc_status_duration_work_hours_start', '09:00');
        $end = get_option('wc_status_duration_work_hours_end', '17:00');
        
        echo '<input type="time" name="wc_status_duration_work_hours_start" value="' . esc_attr($start) . '"> - ';
        echo '<input type="time" name="wc_status_duration_work_hours_end" value="' . esc_attr($end) . '">';
    }
    
    public function working_days_callback() {
        $days = get_option('wc_status_duration_working_days', ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']);
        $all_days = [
            'monday' => 'Pazartesi',
            'tuesday' => 'Salı',
            'wednesday' => 'Çarşamba',
            'thursday' => 'Perşembe',
            'friday' => 'Cuma',
            'saturday' => 'Cumartesi',
            'sunday' => 'Pazar'
        ];
        
        foreach ($all_days as $day_key => $day_label) {
            $checked = in_array($day_key, $days) ? 'checked' : '';
            echo '<label style="margin-right:15px;"><input type="checkbox" name="wc_status_duration_working_days[]" value="' . esc_attr($day_key) . '" ' . $checked . '> ' . $day_label . '</label>';
        }
    }
    
    /**
     * Durum tahminleri için input alanı oluştur
     */
    public function estimate_field_callback($args) {
        $status = $args['status'];
        $option_name = 'wc_status_duration_estimate_' . $status;
        $value = get_option($option_name, '');
        
        echo '<input type="number" name="' . esc_attr($option_name) . '" value="' . esc_attr($value) . '" min="0"> ';
        echo '<span class="description">dakika</span>';
    }
    
    /**
     * Ayarlar sayfasını render et
     */
    public function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('Bu sayfaya erişim izniniz yok.'));
        }
        
        // Aktif sekmeyi belirle
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'notifications';
        ?>
        <div class="wrap">
            <h1>Sipariş Durumu Süre Ayarları</h1>
            
            <h2 class="nav-tab-wrapper">
                <a href="?page=wc-status-duration-settings&tab=notifications" class="nav-tab <?php echo $active_tab == 'notifications' ? 'nav-tab-active' : ''; ?>">Bildirimler</a>
                <a href="?page=wc-status-duration-settings&tab=production" class="nav-tab <?php echo $active_tab == 'production' ? 'nav-tab-active' : ''; ?>">Üretim Ayarları</a>
                <a href="?page=wc-status-duration-settings&tab=estimates" class="nav-tab <?php echo $active_tab == 'estimates' ? 'nav-tab-active' : ''; ?>">Süre Tahminleri</a>
                <a href="?page=wc-status-duration-settings&tab=maintenance" class="nav-tab <?php echo $active_tab == 'maintenance' ? 'nav-tab-active' : ''; ?>">Bakım</a>
            </h2>
            
            <?php if ($active_tab == 'notifications'): ?>
            
                <form method="post" action="options.php">
                    <?php 
                    settings_fields('wc_status_duration_settings_group');
                    do_settings_sections('wc_status_duration_settings');
                    submit_button('Ayarları Kaydet');
                    ?>
                </form>
                
            <?php elseif ($active_tab == 'production'): ?>
            
                <form method="post" action="options.php">
                    <?php 
                    settings_fields('wc_status_duration_production_group');
                    do_settings_sections('wc_status_duration_production');
                    submit_button('Ayarları Kaydet');
                    ?>
                </form>
                
            <?php elseif ($active_tab == 'estimates'): ?>
            
                <form method="post" action="options.php">
                    <?php 
                    settings_fields('wc_status_duration_estimates_group');
                    do_settings_sections('wc_status_duration_estimates');
                    submit_button('Ayarları Kaydet');
                    ?>
                </form>
                
            <?php elseif ($active_tab == 'maintenance'): ?>
                
                <h2>Bakım İşlemleri</h2>
                <table class="form-table">
                    <tr>
                        <th>Önbellek Yönetimi</th>
                        <td>
                            <button type="button" id="clear-cache" class="button">Önbelleği Temizle</button>
                            <p class="description">Bu işlem, performansı iyileştirmek için önbelleği temizler, verileriniz korunur.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Veri Temizleme</th>
                        <td>
                            <button type="button" id="clear-old-data" class="button">6 Aydan Eski Verileri Temizle</button>
                            <p class="description">Bu işlem, 6 aydan daha eski sipariş durum değişikliği verilerini kaldırır.</p>
                        </td>
                    </tr>
                </table>
                
                <script>
                jQuery(document).ready(function($) {
                    $('#clear-old-data').on('click', function() {
                        if (confirm('Bu işlem, 6 aydan eski tüm sipariş durum verilerini kalıcı olarak silecektir. Devam etmek istiyor musunuz?')) {
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'wc_status_duration_clear_data',
                                    nonce: '<?php echo wp_create_nonce('wc_status_duration_clear_data'); ?>'
                                },
                                beforeSend: function() {
                                    $('#clear-old-data').prop('disabled', true).text('İşleniyor...');
                                },
                                success: function(response) {
                                    $('#clear-old-data').prop('disabled', false).text('6 Aydan Eski Verileri Temizle');
                                    alert('Eski veriler başarıyla temizlendi!');
                                },
                                error: function() {
                                    $('#clear-old-data').prop('disabled', false).text('6 Aydan Eski Verileri Temizle');
                                    alert('İşlem sırasında bir hata oluştu.');
                                }
                            });
                        }
                    });
                    
                    $('#clear-cache').on('click', function() {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'wc_status_duration_clear_cache',
                                nonce: '<?php echo wp_create_nonce('wc_status_duration_clear_cache'); ?>'
                            },
                            beforeSend: function() {
                                $('#clear-cache').prop('disabled', true).text('İşleniyor...');
                            },
                            success: function(response) {
                                $('#clear-cache').prop('disabled', false).text('Önbelleği Temizle');
                                alert('Önbellek başarıyla temizlendi!');
                            },
                            error: function() {
                                $('#clear-cache').prop('disabled', false).text('Önbelleği Temizle');
                                alert('İşlem sırasında bir hata oluştu.');
                            }
                        });
                    });
                });
                </script>
                
            <?php endif; ?>
        </div>
        <?php
    }
}