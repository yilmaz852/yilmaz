<?php
/**
 * UI yardımcıları için sınıf
 */

if (!defined('ABSPATH')) exit;

class WC_Status_Duration_UI {
    /**
     * Gelişmiş filtreler için UI bileşenlerini render eder
     */
    public static function render_advanced_filters() {
        // Status dropdown instead of text input
        $statuses = wc_get_order_statuses();
        echo '<select name="status">';
        echo '<option value="">Tüm Durumlar</option>';
        foreach ($statuses as $key => $label) {
            $selected = (isset($_GET['status']) && $_GET['status'] === str_replace('wc-', '', $key)) ? 'selected' : '';
            echo '<option value="' . esc_attr(str_replace('wc-', '', $key)) . '" ' . $selected . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        
        // Product category filter - opsiyonel olarak eklenebilir
        if (false) { // İhtiyaç olursa etkinleştirin
            $categories = get_terms('product_cat', ['hide_empty' => true]);
            echo '<select name="category">';
            echo '<option value="">Tüm Kategoriler</option>';
            foreach ($categories as $category) {
                $selected = (isset($_GET['category']) && $_GET['category'] == $category->term_id) ? 'selected' : '';
                echo '<option value="' . esc_attr($category->term_id) . '" ' . $selected . '>' . esc_html($category->name) . '</option>';
            }
            echo '</select>';
        }
    }
    
    /**
     * Sayfalama UI bileşeni
     */
    public static function render_pagination($total_items, $per_page = 20) {
        $current_page = isset($_GET['paged']) ? (int)$_GET['paged'] : 1;
        $total_pages = ceil($total_items / $per_page);
        
        echo '<div class="tablenav-pages">';
        echo '<span class="displaying-num">' . sprintf(_n('%s öğe', '%s öğeler', $total_items), number_format_i18n($total_items)) . '</span>';
        
        if ($total_pages > 1) {
            $page_links = paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $current_page
            ]);
            echo "<span class=\"pagination-links\">$page_links</span>";
        }
        
        echo '</div>';
    }
    
    /**
     * Hata veya bilgi mesajı gösterme
     */
    public static function show_notice($message, $type = 'info') {
        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible">';
        echo '<p>' . esc_html($message) . '</p>';
        echo '</div>';
    }
    
    /**
     * Grafik renkleri oluşturma
     */
    public static function get_chart_colors($count = 10) {
        $colors = [
            '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
            '#6f42c1', '#fd7e14', '#20c997', '#f8f9fc', '#858796'
        ];
        
        return array_slice($colors, 0, min($count, count($colors)));
    }
}