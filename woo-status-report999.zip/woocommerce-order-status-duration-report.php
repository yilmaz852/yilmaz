<?php
/*
Plugin Name: WooCommerce Order Status Duration Report
Description: WooCommerce siparişlerinin her statüde ne kadar kaldığını analiz eder, raporlar, filtreler, tahminler yapar ve CSV olarak dışa aktarır.
Version: 2.1.0
Author: Yilmaz
*/

if (!defined('ABSPATH')) exit;

// Yardımcı sınıfları dahil et
if (!class_exists('WC_Status_Duration_UI')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-ui.php';
}

if (!class_exists('WC_Status_Duration_Cache')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-cache.php';
}

if (!class_exists('WC_Status_Duration_Settings')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-settings.php';
}

if (!class_exists('WC_Status_Duration_Analytics')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-analytics.php';
}

if (!class_exists('WC_Status_Duration_Dashboard')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-dashboard.php';
}

if (!class_exists('WC_Status_Duration_Production')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-production.php';
}

if (!class_exists('WC_Status_Duration_API')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-status-duration-api.php';
}

class WC_Status_Duration_Report {
    private $table_name;
    private $cache;
    private $analytics;
    private $dashboard;
    private $settings;
    private $production;
    private $api;
    private $version = '2.1.0';

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'order_status_history';
        
        // Yardımcı sınıfları başlat
        $this->cache = new WC_Status_Duration_Cache();
        $this->analytics = new WC_Status_Duration_Analytics();
        $this->dashboard = new WC_Status_Duration_Dashboard($this->table_name);
        $this->settings = new WC_Status_Duration_Settings($this->table_name);
        $this->production = new WC_Status_Duration_Production($this->table_name, $this->cache);
        $this->api = new WC_Status_Duration_API($this->table_name, $this->cache);

        // Kancaları ekle
        register_activation_hook(__FILE__, [$this, 'activate_plugin']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate_plugin']);
        
        add_action('plugins_loaded', [$this, 'check_version']);
        add_action('woocommerce_order_status_changed', [$this, 'log_status_change'], 10, 4);
        add_action('add_meta_boxes', [$this, 'add_order_meta_box']);
        add_action('admin_menu', [$this, 'add_report_page']);
        add_action('admin_init', [$this, 'handle_csv_export']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_wc_status_duration_clear_data', [$this, 'ajax_clear_old_data']);
        
        // REST API ile veri erişimi için
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }
    
    public function activate_plugin() {
        $this->create_table();
        $this->set_version();
        
        // WooCommerce yüklü mü kontrol et
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die('Bu eklenti için WooCommerce yüklü olmalıdır.');
        }
    }
    
    public function deactivate_plugin() {
        // Gerekirse devre dışı bırakma işlemleri
    }
    
    public function set_version() {
        update_option('wc_status_duration_version', $this->version);
    }
    
    public function check_version() {
        $installed_version = get_option('wc_status_duration_version', '1.0');
        
        if (version_compare($installed_version, $this->version, '<')) {
            // Versiyon güncelleme işlemleri
            $this->update_plugin_version($installed_version);
            update_option('wc_status_duration_version', $this->version);
        }
    }
    
    public function update_plugin_version($old_version) {
        // Versiyon geçişlerindeki değişiklikleri uygula
        if (version_compare($old_version, '2.0', '<')) {
            // 2.0 versiyonu için gerekli değişiklikler
            global $wpdb;
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM {$this->table_name} LIKE 'meta'");
            
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE {$this->table_name} ADD COLUMN meta TEXT");
            }
        }
    }
    
    public function create_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            order_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(100) NOT NULL,
            changed_at DATETIME NOT NULL,
            meta TEXT,
            INDEX idx_order_status (order_id, status),
            INDEX idx_changed_at (changed_at)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function log_status_change($order_id, $old_status, $new_status, $order) {
        global $wpdb;
        
        // Meta bilgilerini topla
        $meta = [
            'user_id' => get_current_user_id(),
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
            'previous_status' => $old_status,
        ];
        
        $wpdb->insert($this->table_name, [
            'order_id'    => $order_id,
            'status'      => $new_status,
            'changed_at'  => current_time('mysql'),
            'meta'        => json_encode($meta),
        ]);
        
        // Önbelleği temizle
        $this->cache->clear_cache();
    }

    public function add_order_meta_box() {
        add_meta_box(
            'order_status_duration',
            'Sipariş Durum Süreleri',
            [$this, 'render_order_meta_box'],
            'shop_order',
            'side',
            'default'
        );
    }

    public function render_order_meta_box($post) {
        global $wpdb;
        
        // Önbellekten veri al veya veritabanından çek
        $results = $this->cache->get_cached_data(
            'order_meta_' . $post->ID,
            function($order_id) use ($wpdb) {
                return $wpdb->get_results($wpdb->prepare(
                    "SELECT status, changed_at FROM {$this->table_name} WHERE order_id = %d ORDER BY changed_at ASC",
                    $order_id
                ));
            },
            [$post->ID]
        );

        if (!$results) {
            echo '<p>Veri yok.</p>';
            return;
        }
        
        echo '<table class="widefat"><tr><th>Durum</th><th>Geçiş Zamanı</th><th>Süre</th></tr>';
        $prev_time = null;
        foreach ($results as $row) {
            $duration = '';
            if ($prev_time) {
                $diff = strtotime($row->changed_at) - strtotime($prev_time);
                $duration = gmdate('H:i:s', $diff);
            }
            echo '<tr>' .
                 '<td>' . esc_html($row->status) . '</td>' .
                 '<td>' . esc_html($row->changed_at) . '</td>' .
                 '<td>' . esc_html($duration) . '</td>' .
                 '</tr>';
            $prev_time = $row->changed_at;
        }
        echo '</table>';
    }

    public function add_report_page() {
        add_menu_page(
            'Durum Süre Raporu',
            'Durum Süre Raporu',
            'manage_woocommerce',
            'wc-status-duration-report',
            [$this, 'render_report_page'],
            'dashicons-chart-line'
        );
        
        // Alt sayfalar ekle
        add_submenu_page(
            'wc-status-duration-report',
            'Gelişmiş Analiz',
            'Gelişmiş Analiz',
            'manage_woocommerce',
            'wc-status-duration-analysis',
            [$this, 'render_analysis_page']
        );
        
        add_submenu_page(
            'wc-status-duration-report',
            'Ayarlar',
            'Ayarlar',
            'manage_woocommerce',
            'wc-status-duration-settings',
            [$this->settings, 'render_settings_page']
        );
    }

    public function render_report_page() {
        global $wpdb;
        // Filtre sorguları
        $where = 'WHERE 1=1';
        if (!empty($_GET['start_date'])) {
            $where .= $wpdb->prepare(" AND changed_at >= %s", sanitize_text_field($_GET['start_date']) . ' 00:00:00');
        }
        if (!empty($_GET['end_date'])) {
            $where .= $wpdb->prepare(" AND changed_at <= %s", sanitize_text_field($_GET['end_date']) . ' 23:59:59');
        }
        if (!empty($_GET['status'])) {
            $where .= $wpdb->prepare(" AND status = %s", sanitize_text_field($_GET['status']));
        }

        echo '<div class="wrap"><h1>Sipariş Durum Süre Raporu</h1>';
        
        // Gelişmiş filtreler
        echo '<form method="get" class="wc-status-filter-form">';
        echo '<input type="hidden" name="page" value="wc-status-duration-report">';
        echo '<div class="filter-row">';
        echo 'Başlangıç: <input type="date" name="start_date" value="' . esc_attr(isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '') . '"> ';
        echo 'Bitiş: <input type="date" name="end_date" value="' . esc_attr(isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '') . '"> ';
        
        // Status dropdown
        WC_Status_Duration_UI::render_advanced_filters();
        
        echo '<input type="submit" class="button" value="Filtrele">';
        echo '</div></form><br>';
        
        // CSV butonu
        echo '<form method="post" id="export-csv-form">';
        if (!empty($_GET['start_date'])) {
            echo '<input type="hidden" name="start_date" value="' . esc_attr(sanitize_text_field($_GET['start_date'])) . '">';
        }
        if (!empty($_GET['end_date'])) {
            echo '<input type="hidden" name="end_date" value="' . esc_attr(sanitize_text_field($_GET['end_date'])) . '">';
        }
        if (!empty($_GET['status'])) {
            echo '<input type="hidden" name="status" value="' . esc_attr(sanitize_text_field($_GET['status'])) . '">';
        }
        echo '<input type="submit" name="export_csv" class="button button-primary" value="CSV Export">';
        echo '</form><br>';

        // Veriyi önbellekten al (filtrelere göre)
        $cache_key = md5(serialize($_GET));
        $report_data = $this->cache->get_cached_data(
            'report_' . $cache_key,
            function() use ($wpdb, $where) {
                $rows = $wpdb->get_results(
                    "SELECT order_id, status, changed_at FROM {$this->table_name} $where ORDER BY order_id, changed_at"
                );
                
                // Durasyon hesapla
                $durations = [];
                $prev = [];
                foreach ($rows as $r) {
                    if (!isset($prev[$r->order_id])) {
                        $prev[$r->order_id] = $r->changed_at;
                        $prev['status'][$r->order_id] = $r->status;
                        continue;
                    }
                    $sec = strtotime($r->changed_at) - strtotime($prev[$r->order_id]);
                    if (!isset($durations[$prev['status'][$r->order_id]])) {
                        $durations[$prev['status'][$r->order_id]] = [];
                    }
                    $durations[$prev['status'][$r->order_id]][] = $sec;
                    $prev[$r->order_id] = $r->changed_at;
                    $prev['status'][$r->order_id] = $r->status;
                }
                
                return ['rows' => $rows, 'durations' => $durations];
            }
        );
        
        $durations = $report_data['durations'] ?? [];

        // Durum var mı kontrol et
        if (empty($durations)) {
            echo '<div class="notice notice-warning"><p>Seçilen filtreler için veri bulunamadı.</p></div>';
        } else {
            // Ortalama, min, max
            $avg_secs = [];
            echo '<table class="widefat"><thead><tr><th>Durum</th><th>Ortalama</th><th>En Kısa</th><th>En Uzun</th><th>Toplam Sipariş</th></tr></thead><tbody>';
            foreach ($durations as $st => $list) {
                if (empty($list)) continue;
                $avg = round(array_sum($list)/count($list));
                $min = min($list);
                $max = max($list);
                $avg_secs[$st] = $avg;
                echo '<tr>' .
                     '<td>' . esc_html($st) . '</td>' .
                     '<td>' . gmdate('H:i:s', $avg) . '</td>' .
                     '<td>' . gmdate('H:i:s', $min) . '</td>' .
                     '<td>' . gmdate('H:i:s', $max) . '</td>' .
                     '<td>' . count($list) . '</td>' .
                     '</tr>';
            }
            echo '</tbody></table>';

            // Gelişmiş grafik
            echo '<div class="chart-container" style="position: relative; height:40vh; width:80vw; margin: 20px auto;">
                    <canvas id="durationChart"></canvas>
                  </div>';
            
            // JavaScript'i alt tarafa taşı
            add_action('admin_footer', function() use ($avg_secs) {
                ?>
                <script>
                jQuery(document).ready(function($) {
                    var ctx = document.getElementById('durationChart').getContext('2d');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: <?php echo json_encode(array_keys($avg_secs)); ?>,
                            datasets: [{
                                label: 'Ortalama Süre (sn)',
                                data: <?php echo json_encode(array_values($avg_secs)); ?>,
                                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'Saniye'
                                    }
                                }
                            },
                            plugins: {
                                legend: {
                                    position: 'top',
                                },
                                title: {
                                    display: true,
                                    text: 'Durum Başına Ortalama Süre'
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            var seconds = context.raw;
                                            var hours = Math.floor(seconds / 3600);
                                            var minutes = Math.floor((seconds % 3600) / 60);
                                            var secs = seconds % 60;
                                            
                                            return 'Ortalama Süre: ' + 
                                                (hours < 10 ? '0' + hours : hours) + ':' + 
                                                (minutes < 10 ? '0' + minutes : minutes) + ':' + 
                                                (secs < 10 ? '0' + secs : secs);
                                        }
                                    }
                                }
                            }
                        }
                    });
                });
                </script>
                <?php
            });
        }

        // Tahmin kısmına geçiş
        $this->render_predictions();
        
        echo '</div>';
    }
    
    public function render_predictions() {
        global $wpdb;
        
        // Tahminleri hesapla
        $hist = $wpdb->get_results(
            "SELECT order_id, status, MAX(changed_at) as last_time FROM {$this->table_name} GROUP BY order_id"
        );
        
        // Ortalama süreler (daha önceden hesaplanan)
        $avg_durations = $this->cache->get_cached_data(
            'avg_durations',
            function() use ($wpdb) {
                $results = $wpdb->get_results(
                    "SELECT 
                        a.status, 
                        AVG(TIMESTAMPDIFF(SECOND, a.changed_at, b.changed_at)) as avg_sec
                     FROM 
                        {$this->table_name} a
                     JOIN 
                        {$this->table_name} b ON a.order_id = b.order_id AND a.changed_at < b.changed_at
                     WHERE 
                        (a.order_id, a.changed_at) IN (
                            SELECT order_id, MAX(changed_at) 
                            FROM {$this->table_name}
                            GROUP BY order_id, status
                        )
                     GROUP BY 
                        a.status"
                );
                
                $durations = [];
                foreach ($results as $row) {
                    $durations[$row->status] = $row->avg_sec;
                }
                return $durations;
            }
        );
        
        // Durum geçişlerini belirle
        $status_transitions = $this->get_status_transitions();
        
        $preds = [];
        foreach ($hist as $h) {
            // Sadece tamamlanmamış
            if (in_array($h->status, ['completed','cancelled','refunded'])) continue;
            
            $remaining = 0;
            $next_transitions = [];
            $current_status = $h->status;
            
            // Geçiş ağacı üzerinde dolaşarak sonraki durumları bul
            while (isset($status_transitions[$current_status]) && !empty($status_transitions[$current_status])) {
                $next_status = $status_transitions[$current_status][0]; // En yaygın geçiş
                $next_transitions[] = $next_status;
                
                if (isset($avg_durations[$current_status])) {
                    $remaining += $avg_durations[$current_status];
                }
                
                // Tamamlandı veya iptal durumlarında döngüyü sonlandır
                if (in_array($next_status, ['completed','cancelled','refunded'])) {
                    break;
                }
                
                $current_status = $next_status;
            }
            
            $preds[] = [
                'order_id' => $h->order_id,
                'status' => $h->status,
                'last_time' => $h->last_time,
                'remaining' => $remaining,
                'eta' => date('Y-m-d H:i:s', strtotime($h->last_time) + $remaining),
                'next_transitions' => $next_transitions
            ];
        }
        
        if (!empty($preds)) {
            echo '<h2>Açık Sipariş Tahmini</h2>';
            echo '<p class="description">Bu tahminler, geçmiş sipariş verilerine dayanarak her durumun ortalama süresine göre hesaplanır.</p>';
            echo '<table class="widefat"><thead><tr>
                <th>Sipariş ID</th>
                <th>Mevcut Durum</th>
                <th>Son Değişim</th>
                <th>Kalan Tahmini Süre</th>
                <th>Tahmini Tamamlanma</th>
                <th>Sonraki Durumlar</th>
                </tr></thead><tbody>';
            
            $sumRem = 0;
            foreach ($preds as $p) {
                $sumRem += $p['remaining'];
                $order_link = admin_url('post.php?post=' . $p['order_id'] . '&action=edit');
                echo '<tr>' .
                     '<td><a href="' . esc_url($order_link) . '">' . esc_html($p['order_id']) . '</a></td>' .
                     '<td>' . esc_html($p['status']) . '</td>' .
                     '<td>' . esc_html($p['last_time']) . '</td>' .
                     '<td>' . gmdate('H:i:s', $p['remaining']) . '</td>' .
                     '<td>' . esc_html($p['eta']) . '</td>' .
                     '<td>' . esc_html(implode(' → ', $p['next_transitions'])) . '</td>' .
                     '</tr>';
            }
            
            $avgPred = count($preds) > 0 ? round($sumRem/count($preds)) : 0;
            echo '</tbody></table>';
            echo '<p>Mevcut açık siparişlerin ortalama tamamlanma süresi: <strong>' . gmdate('H:i:s', $avgPred) . '</strong></p>';
            
            // Doğruluk oranı
            $accuracy = $this->analytics->get_prediction_accuracy();
            echo '<p>Tahmin doğruluk oranı: <strong>' . $accuracy['accuracy_percentage'] . '%</strong> (ortalama hata: ' . gmdate('H:i:s', $accuracy['avg_error']) . ')</p>';
        } else {
            echo '<h2>Açık Sipariş Tahmini</h2>';
            echo '<p>Şu anda açık sipariş bulunmuyor veya tüm siparişler tamamlanmış durumda.</p>';
        }
    }
    
    private function get_status_transitions() {
        global $wpdb;
        
        return $this->cache->get_cached_data(
            'status_transitions',
            function() use ($wpdb) {
                $results = $wpdb->get_results(
                    "SELECT 
                        a.status as from_status, 
                        b.status as to_status,
                        COUNT(*) as transition_count
                    FROM 
                        {$this->table_name} a
                    JOIN 
                        {$this->table_name} b ON a.order_id = b.order_id AND a.changed_at < b.changed_at
                    WHERE 
                        (a.order_id, a.changed_at) IN (
                            SELECT order_id, MAX(changed_at) as max_time
                            FROM {$this->table_name} x
                            WHERE x.changed_at < b.changed_at
                            GROUP BY order_id
                        )
                    GROUP BY 
                        a.status, b.status
                    ORDER BY 
                        a.status, transition_count DESC"
                );
                
                $transitions = [];
                foreach ($results as $row) {
                    if (!isset($transitions[$row->from_status])) {
                        $transitions[$row->from_status] = [];
                    }
                    $transitions[$row->from_status][] = $row->to_status;
                }
                
                return $transitions;
            }
        );
    }
    
    public function render_analysis_page() {
        echo '<div class="wrap"><h1>Gelişmiş Sipariş Durum Analizi</h1>';
        
        // Gelişmiş trend grafiği
        $this->analytics->render_advanced_charts($this->table_name);
        
        echo '</div>';
    }

    public function enqueue_admin_scripts($hook) {
        // Chart.js kütüphanesini yükle (sadece ilgili sayfalarda)
        if (strpos($hook, 'wc-status-duration') !== false) {
            wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '3.9.1', true);
            
            // CSS ve JS dosyalarını yükle
            $css_path = plugin_dir_path(__FILE__) . 'assets/css/admin-style.css';
            if (file_exists($css_path)) {
                wp_enqueue_style('wc-status-duration-css', plugin_dir_url(__FILE__) . 'assets/css/admin-style.css', [], $this->version);
            } else {
                // CSS dosyası yoksa inline CSS ekle
                add_action('admin_head', function() {
                    ?>
                    <style>
                    .wc-status-filter-form {
                        background: #fff;
                        padding: 15px;
                        border: 1px solid #ccd0d4;
                        margin-bottom: 20px;
                    }
                    .date-filter, .filter-row {
                        display: flex;
                        align-items: center;
                        gap: 10px;
                        flex-wrap: wrap;
                        margin-bottom: 10px;
                    }
                    .analytics-container {
                        background: #fff;
                        padding: 20px;
                        border: 1px solid #ccd0d4;
                        margin: 20px 0;
                    }
                    .chart-container {
                        background: #fff;
                        padding: 20px;
                        border: 1px solid #ccd0d4;
                    }
                    @media (max-width: 782px) {
                        .date-filter, .filter-row {
                            flex-direction: column;
                            align-items: flex-start;
                        }
                        .date-filter input, .date-filter select,
                        .filter-row input, .filter-row select {
                            width: 100%;
                        }
                    }
                    </style>
                    <?php
                });
            }
            
            $js_path = plugin_dir_path(__FILE__) . 'assets/js/admin-script.js';
            if (file_exists($js_path)) {
                wp_enqueue_script('wc-status-duration-js', plugin_dir_url(__FILE__) . 'assets/js/admin-script.js', ['jquery', 'chart-js'], $this->version, true);
            } else {
                // JS dosyası yoksa inline JS ekle
                add_action('admin_footer', function() {
                    ?>
                    <script>
                    jQuery(document).ready(function($) {
                        // Tarih alanlarına varsayılan değerler
                        if ($('input[name="start_date"]').val() === '') {
                            const thirtyDaysAgo = new Date();
                            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                            $('input[name="start_date"]').val(thirtyDaysAgo.toISOString().split('T')[0]);
                        }
                        
                        if ($('input[name="end_date"]').val() === '') {
                            const today = new Date();
                            $('input[name="end_date"]').val(today.toISOString().split('T')[0]);
                        }
                    });
                    </script>
                    <?php
                });
            }
        }
    }
    
    public function ajax_clear_old_data() {
        // Güvenlik kontrolü
        check_ajax_referer('wc_status_duration_clear_data', 'nonce');
        
        // Yetki kontrolü
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('İzin hatası');
            return;
        }
        
        global $wpdb;
        $date_threshold = date('Y-m-d H:i:s', strtotime('-6 months'));
        
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE changed_at < %s",
            $date_threshold
        ));
        
        // Önbellekleri temizle
        $this->cache->clear_cache();
        
        wp_send_json_success([
            'message' => sprintf('%d kayıt başarıyla temizlendi.', $deleted)
        ]);
    }
    
    public function handle_csv_export() {
        if (!isset($_POST['export_csv']) || !current_user_can('manage_woocommerce')) {
            return;
        }
        
        global $wpdb;
        
        // Filtre sorguları
        $where = 'WHERE 1=1';
        if (!empty($_POST['start_date'])) {
            $where .= $wpdb->prepare(" AND changed_at >= %s", sanitize_text_field($_POST['start_date']) . ' 00:00:00');
        }
        if (!empty($_POST['end_date'])) {
            $where .= $wpdb->prepare(" AND changed_at <= %s", sanitize_text_field($_POST['end_date']) . ' 23:59:59');
        }
        if (!empty($_POST['status'])) {
            $where .= $wpdb->prepare(" AND status = %s", sanitize_text_field($_POST['status']));
        }
        
        $rows = $wpdb->get_results("SELECT order_id, status, changed_at FROM {$this->table_name} $where ORDER BY order_id, changed_at");
        
        // CSV dosya başlığı ayarla
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=order_status_duration_report_' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $out = fopen('php://output', 'w');
        
        // UTF-8 BOM
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Başlıklar
        fputcsv($out, ['Sipariş ID', 'Durum', 'Geçiş Zamanı', 'Süre (sn)', 'Süre (saat:dakika:saniye)']);
        
        $prev = [];
        foreach ($rows as $r) {
            if (!isset($prev[$r->order_id])) {
                $prev[$r->order_id] = $r->changed_at;
                $prev['status'][$r->order_id] = $r->status;
                continue;
            }
            
            $sec = strtotime($r->changed_at) - strtotime($prev[$r->order_id]);
            fputcsv($out, [
                $r->order_id,
                $prev['status'][$r->order_id],
                $prev[$r->order_id],
                $sec,
                gmdate('H:i:s', $sec)
            ]);
            
            $prev[$r->order_id] = $r->changed_at;
            $prev['status'][$r->order_id] = $r->status;
        }
        
        fclose($out);
        exit;
    }
    
    public function register_rest_routes() {
        register_rest_route('wc-status-duration/v1', '/report', [
            'methods' => 'GET',
            'callback' => [$this, 'get_report_data_api'],
            'permission_callback' => function () {
                return current_user_can('manage_woocommerce');
            }
        ]);
        
        register_rest_route('wc-status-duration/v1', '/orders/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'get_order_history_api'],
            'permission_callback' => function () {
                return current_user_can('manage_woocommerce');
            },
            'args' => [
                'id' => [
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ]
            ]
        ]);
    }
    
    public function get_report_data_api($request) {
        // API yanıtını hazırla
        $params = $request->get_params();
        $start_date = isset($params['start_date']) ? sanitize_text_field($params['start_date']) : date('Y-m-d', strtotime('-30 days'));
        $end_date = isset($params['end_date']) ? sanitize_text_field($params['end_date']) : date('Y-m-d');
        
        global $wpdb;
        $where = 'WHERE 1=1';
        $where .= $wpdb->prepare(" AND changed_at BETWEEN %s AND %s", $start_date . ' 00:00:00', $end_date . ' 23:59:59');
        
        if (!empty($params['status'])) {
            $where .= $wpdb->prepare(" AND status = %s", $params['status']);
        }
        
        $rows = $wpdb->get_results("SELECT order_id, status, changed_at FROM {$this->table_name} $where ORDER BY order_id, changed_at");
        
        // Durasyon hesapla
        $durations = [];
        $prev = [];
        foreach ($rows as $r) {
            if (!isset($prev[$r->order_id])) {
                $prev[$r->order_id] = $r->changed_at;
                $prev['status'][$r->order_id] = $r->status;
                continue;
            }
            $sec = strtotime($r->changed_at) - strtotime($prev[$r->order_id]);
            if (!isset($durations[$prev['status'][$r->order_id]])) {
                $durations[$prev['status'][$r->order_id]] = [];
            }
            $durations[$prev['status'][$r->order_id]][] = $sec;
            $prev[$r->order_id] = $r->changed_at;
            $prev['status'][$r->order_id] = $r->status;
        }
        
        // İstatistikleri hazırla
        $stats = [];
        foreach ($durations as $st => $list) {
            if (!empty($list)) {
                $stats[$st] = [
                    'avg' => round(array_sum($list)/count($list)),
                    'min' => min($list),
                    'max' => max($list),
                    'count' => count($list),
                    'total' => array_sum($list),
                    'formatted' => [
                        'avg' => gmdate('H:i:s', round(array_sum($list)/count($list))),
                        'min' => gmdate('H:i:s', min($list)),
                        'max' => gmdate('H:i:s', max($list))
                    ]
                ];
            }
        }
        
        return new WP_REST_Response([
            'success' => true,
            'stats' => $stats,
            'period' => [
                'start' => $start_date,
                'end' => $end_date
            ]
        ], 200);
    }
    
    public function get_order_history_api($request) {
        $order_id = $request->get_param('id');
        
        global $wpdb;
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT id, status, changed_at, meta FROM {$this->table_name} WHERE order_id = %d ORDER BY changed_at ASC",
            $order_id
        ));
        
        if (empty($results)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Sipariş geçmişi bulunamadı.'
            ], 404);
        }
        
        $history = [];
        $prev_time = null;
        
        foreach ($results as $row) {
            $duration = null;
            if ($prev_time) {
                $duration = strtotime($row->changed_at) - strtotime($prev_time);
            }
            
            $meta = !empty($row->meta) ? json_decode($row->meta, true) : [];
            
            $history[] = [
                'id' => $row->id,
                'status' => $row->status,
                'changed_at' => $row->changed_at,
                'duration' => $duration,
                'duration_formatted' => $duration ? gmdate('H:i:s', $duration) : null,
                'meta' => $meta
            ];
            
            $prev_time = $row->changed_at;
        }
        
        return new WP_REST_Response([
            'success' => true,
            'order_id' => $order_id,
            'history' => $history
        ], 200);
    }
}

// Plugin'i başlat
new WC_Status_Duration_Report();